#define _GNU_SOURCE
#include <stdio.h>
#include <math.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include <stdlib.h>
#include "golden.h"

#define UNLIMIT



#define MOD 1000

#define NUM_EXEC 10

#define US_TO_S 0.000001
#define US_TO_MS 0.001

#define APP_SUCCESS            0xAA000000
#define APP_SDC            	   0xDD000000 //SDC
#ifndef MAXARRAY
#define MAXARRAY 50000
#endif
int s;

unsigned int buffer[4];
int array[3*MAXARRAY];
double distance[MAXARRAY];

// TIMER instance
//XTmrCtr timer_dev;



void initInput(char* input_file){
    FILE* fp;
    int i;
    fp = fopen(input_file,"rb");
    fread(&array[i],sizeof(double)*3*MAXARRAY,1,fp);
    fclose(fp);
}
void qsort(void *base, size_t nitems, size_t size, int (*compar)(const void *, const void*));
//---------------------------------------------------------------------------


//void qsort(void *base, size_t nitems, size_t size, int (*compar)(const void *, const void*));
int compare(const void *elem1, const void *elem2);
int compare(const void *elem1, const void *elem2)
{
  /* D = [(x1 - x2)^2 + (y1 - y2)^2 + (z1 - z2)^2]^(1/2) */
  /* sort based on distances from the origin... */
 // printf("hello\n\r");
  double distance1, distance2;

  distance1 = *((double*)elem1);
  distance2 = *((double*)elem2);
//printf("%f %f %d",distance1,distance2,(distance1 > distance2) ? 1 : ((distance1 < distance2) ? -1 : 0));
  return (distance1 > distance2) ? 1 : ((distance1 < distance2) ? -1 : 0);
}

int array[3*MAXARRAY];
double distance[MAXARRAY];
long long temp_gold[MAXARRAY];

//---------------------------------------------------------------------------
int main(int argc, char **argv)
{
	int Status = 0;

    int status_app=0;
    int i;
    int ex=0;
    uint64_t aux;
    int endexec=0;
    int count=0,count2=0;

    int x,y,z;
	int cont=0,num_erros=0;
    initInput(argv[1]);

    int num_SDCs = 0;
        count=0;
        count2=0;
    //printf("0\n");

    //status_app    = 0x00000000;
    //########### control_dut ###########
    while((count < 3*MAXARRAY)) {
        distance[count2] = sqrt(pow(array[count], 2) + pow(array[count+1], 2) + pow(array[count+2], 2));
        count+=3;
        count2++;
    }

    qsort(distance,MAXARRAY,sizeof(double),compare);


    for (i=0;i<MAXARRAY;i++)
    {
        /*char test[200];
        long *test1=(long*)&distance[i];
        long *test2=(long*)&temp_gold[i];
        sprintf(test,"gold[%d]=0x%08lx%08lx;\n\r",i,test1[1],test1[0]);
        //sprintf(test,"gold[%d]=0x%lx%lx;\n\r",i,test1[1],test1[0]);
        printf (test);*/
        //printf("gold[%d]=0x%llx;\n",i,*((long long *)&distance[i]));
        if (*((long long *)&distance[i]) != temp_gold[i])
            {

                num_SDCs++;


            }
        //printf("a");
    }
    FILE *ptr;
     ptr = fopen("qsort_out.bin","wb");
     fwrite(distance,sizeof(distance),1,ptr);
    //return 0;
    //printf("end");
    //while(1);
    //########### control_dut ###########


    return 0;
}
